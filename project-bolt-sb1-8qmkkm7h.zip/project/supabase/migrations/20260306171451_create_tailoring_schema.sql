/*
  # Create tailoring business database schema

  1. New Tables
    - `bookings` - Store customer booking requests
      - `id` (uuid, primary key)
      - `name` (text) - Customer name
      - `phone` (text) - Customer phone number
      - `service_type` (text) - Type of service
      - `pickup_date` (date) - Preferred pickup date
      - `delivery_date` (date) - Preferred delivery date
      - `special_instructions` (text) - Special requests
      - `user_email` (text) - User email for order tracking
      - `status` (text) - Booking status (pending, confirmed, completed)
      - `created_at` (timestamptz) - Creation timestamp
    
    - `contact_messages` - Store contact form messages
      - `id` (uuid, primary key)
      - `name` (text) - Sender name
      - `email` (text) - Sender email
      - `message` (text) - Message content
      - `status` (text) - Message status (unread, read)
      - `created_at` (timestamptz) - Creation timestamp

  2. Security
    - Enable RLS on all tables
    - Add policies for public read/write to bookings and contact_messages
    - No authentication required for booking form (public service)
*/

CREATE TABLE IF NOT EXISTS bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  phone text NOT NULL,
  service_type text NOT NULL,
  pickup_date date NOT NULL,
  delivery_date date NOT NULL,
  special_instructions text DEFAULT '',
  user_email text,
  status text DEFAULT 'pending',
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS contact_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  message text NOT NULL,
  status text DEFAULT 'unread',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE contact_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can create bookings"
  ON bookings
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Users can view their own bookings"
  ON bookings
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can create contact messages"
  ON contact_messages
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Anyone can view contact messages"
  ON contact_messages
  FOR SELECT
  TO public
  USING (true);
